//Создаем объект калькулятор
let calculator = {
  deleteLast: function(){
    calculator.output = calculator.output.slice(0,-1)
  },
  length: "250px",
  width: "200px",
  
  getButton: function() {
    console.log(this + "hi");
  },
  
  
    get output() {
      return document.getElementById('output').innerText
    },
    set output(value) {
      document.getElementById('output').innerText = value
    },
}
function copytext(){
 var string = document.getElementById("div2").innerHTML;
 print(string);
 }
   //Назначаем всем кнопкам при  клике печатать их значение в поле вывода
   
  function bindbuttons() {
    //Кнопка удаления
    let button_backspace = document.querySelector('.button_backspace')
    button_backspace.addEventListener('click', calculator.deleteLast)
    //Кнопка умножения
    let buttonX = document.querySelector('.buttonX')
    buttonX.addEventListener('click', function(){
    let lastSymbol = calculator.output.substr(-1)
      if(lastSymbol ==='*'||lastSymbol ==='/'||lastSymbol==='+'){
        
      }
        
          document.getElementById('output').innerText += '*'
    })
    //Для всех кнопок цифр и знаков
     let buttons = document.querySelectorAll("div.number, div.sign");
     let buttonClear = document.querySelector('.buttonClear')
     buttonClear.addEventListener('click', function(){
                document.getElementById('output').innerText = ''})
    for(let i = 0;i<=buttons.length - 1; i++){
      buttons[i].addEventListener("click",
        function(){
          document.getElementById('output').classList.remove('result')
          document.getElementById("output").innerText+=buttons[i].innerText;
        }
      )
    }
  }
  //Кнопка равно
  function bindequal() {
       document.getElementById("button-equal").addEventListener("click", 
          function() {
          let result = eval(document.getElementById('output').innerText);
          document.getElementById('output').innerText = eval(result)
           document.getElementById('output').classList.add('result')
          resultLength = result.toString().length
          console.log(resultLength)
          fontSize = getComputedStyle(document.getElementById('output')).fontSize
          console.log(fontSize)
          if (result.toString() === "Infinity") {
            calculator.output = 'ты дурак'
          }
          
          // if (resultLength>=10) {
          //   console.log(result)
          //   console.log(result.toString().slice(0,-10))
          //   document.getElementById('output').innerText = (result.toString().slice(0,-10))
            
            
          // }  
          })
}
  bindbuttons();
  bindequal();
  //Объект секундомер
  let secundomer = {
    end: 10,
    value: 0,
    Id: "no timer",
    target: document.getElementById(output),
    start: function (end){
      secundomer.end = end || secundomer.end;
      function plusvalue(){
        if(secundomer.value<=secundomer.end -1){
          secundomer.value++; console.log(secundomer.value);
        } else{ console.log("Интервал " + "'" + secundomer.Id + "' очищен"); clearInterval(secundomer.Id);
          }
        }
      this.Id = setInterval(plusvalue,500);
    }
    
  }
  
  
  