
document.getElementById("button1").addEventListener("click", changebuttoncolor)

function addButton(){
	var button = document.createElement("button");
	button.innerHTML = "New button";
	button.id="button1"
}
function hello(){
	console.log('Hello World!');}
	function changebuttoncolor() {
		document.getElementById("button1").style.background= ;
	}