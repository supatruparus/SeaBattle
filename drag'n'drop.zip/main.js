let draggables = document.getElementsByClassName("draggable");
let vseDraggables = Array.from(draggables);
console.log(draggables)

addDraggable();
function addDraggable(){
  let maxZindex = 0;
for (var i = 0; i < draggables.length; i++) {
  let draggable = {
    startTouchX:"",
    startTouchY:"",
    offsetX:"",
    offsetY:"",
    startColor: getComputedStyle(draggables[i]).backgroundColor,
    zIndex: "",
    startWidth: "",
    startHeight: "",
  }
  
  draggables[i].addEventListener('touchstart', function(e) {
    event.preventDefault(true);
    draggable.zIndex = parseInt(getComputedStyle(event.target).zIndex);
    let newzindex = maxZindex+1;
    if (maxZindex<newzindex) {
      maxZindex = newzindex;
    }
        event.target.style.zIndex= newzindex;
        
    draggable.startTouchX = event.changedTouches[0].clientX + parseInt(getComputedStyle(event.target).left);
    draggable.startTouchY = event.changedTouches[0].clientY + parseInt(getComputedStyle(event.target).top);
    draggable.offsetX = event.changedTouches[0].clientX - parseInt(getComputedStyle(event.target).left);
  
    draggable.offsetY = event.changedTouches[0].clientY - parseInt(getComputedStyle(event.target).top)
    
    draggable.startWidth = getComputedStyle(event.target).width;
    draggable.startHeight = getComputedStyle(event.target).height;
    increaseSize(event.target, 110)
  });
  
  draggables[i].addEventListener('touchmove', drag);

function drag(){
  //Change Color
  // event.target.style.backgroundColor = "red";
  let startX = parseInt(draggable.startTouchX);
  let startY = parseInt(draggable.startTouchY);
  let deltaX = event.changedTouches[0].clientX.toFixed(0) - parseInt(draggable.startTouchX) - draggable.offsetX;
  
  let deltaY = event.changedTouches[0].clientY.toFixed(0) - parseInt(draggable.startTouchY) - draggable.offsetY;
  
    
        let newposition = { 
      x: startX + deltaX + "px",
      y: startY + deltaY +"px",
    }
  event.target.style.left =newposition.x;
  event.target.style.top = newposition.y;
}
draggables[i].addEventListener('touchend', drop, event);

function drop() {
  // event.target.style.backgroundColor = draggable.startColor;
  event.target.style.width = draggable.startWidth;
  event.target.style.height = draggable.startHeight;
  
  // event.target.style.transform = "translate(+5%,+5%)";
}
}
}
function increaseSize(elem, percent) {

  let newWidth = parseInt(getComputedStyle(elem).width) / 100 * percent + "px";
  let newHeight = parseInt(getComputedStyle(elem).height) / 100 * percent + "px";
  elem.style.width = newWidth;
  elem.style.height = newHeight;
  let trpercent = (percent - 100) / 4;
  elem.style.transform = "translate(-"+(percent-100)/4+"%, -"+(percent-100)/4+"%)";
}
