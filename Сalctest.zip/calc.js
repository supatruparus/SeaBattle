	w =2;
        function setvalue(width){
    				 				w=width
    				 }
        function calculate(){

            r = parseFloat(document.calculator.radius.value.replace(/,/, '.'));
            v = parseFloat(document.calculator.vitki.value.replace(/,/, '.'));
            
            result = (r+r+23)/100*3.15 / 2 * v * w;
            document.getElementById('Sresult').innerHTML=parseFloat(result).toFixed(2);
            document.getElementById('Length').innerHTML= parseFloat(result/w);
            document.getElementById('width_form').style.height = '0px' ;
             document.getElementById('width_form').style.border = 'none' ;
        } 
     