<script>
//скрипт времени

  function getTime(){
    
    var date = new Date();
      document.getElementById('date').innerHTML= date.getHours() + ' : ' + date.getMinutes() +' : ' + date.getSeconds();
    
  }
  function starttime(){
  window.setInterval(getTime, 1000);}
  starttime();
</script>