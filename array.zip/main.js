document.body.addEventListener("click", copytext,this);

  
  
  
function print(string){
  document.getElementById("blackblock").innerHTML= string;
  
}
function copytext(){
 var string = document.getElementById("div2").innerHTML;
 print(string);
 

 
}
var calculator = {
  length: "250px",
  width: "200px",
  b_size: "30",
    sum: function(a,b){
    let x = a+b;
    return x;
    
  },
    multiply: function(a,b){
    var x=a*b;
    return x;
  },
    print: function (string){
      let output = document.getElementById("output").innerHTML;
    },
  }
  console.log(typeof calculator);
  document.addEventListener("click",clearconsole);
function clearconsole (){
  
  console.clear();
}

  calculator.print("hi daun");